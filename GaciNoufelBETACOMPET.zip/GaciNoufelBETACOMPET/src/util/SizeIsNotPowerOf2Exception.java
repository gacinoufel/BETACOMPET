package util;

/**
 * @author  GACI Noufel
 * @version 1.0
 */


public class SizeIsNotPowerOf2Exception extends Exception {

	public SizeIsNotPowerOf2Exception(String msg) {
		super(msg);
	}


}
