package competition.strategy;


public class FirstOfGroupStageStrategyTest extends SelectionStrategyTest {
	

	protected SelectionStrategy createStrategy() {	
		return new FirstOfGroupStageStrategy();
		
	}


}
